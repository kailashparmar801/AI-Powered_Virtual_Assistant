Chatbot Model
