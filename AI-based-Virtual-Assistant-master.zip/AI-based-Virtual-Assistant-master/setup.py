status = "Shivam"
music_path = "E:\\Song"
