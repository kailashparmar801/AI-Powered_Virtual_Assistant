from assistant_details import name
from colorama import Fore

def take_input():
	# Command line input
	i = input(Fore.BLUE + "Me : " + Fore.RESET)
	return i
